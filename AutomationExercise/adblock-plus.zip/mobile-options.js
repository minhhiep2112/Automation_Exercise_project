/*
 * This file is part of Adblock Plus <https://adblockplus.org/>,
 * Copyright (C) 2006-present eyeo GmbH
 *
 * Adblock Plus is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation.
 *
 * Adblock Plus is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Adblock Plus.  If not, see <http://www.gnu.org/licenses/>.
 */ /* eslint-disable */
(function(){'use strict';function __rest(s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
}
function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}let port;
const connectListeners = new Set();
const disconnectListeners = new Set();
const messageListeners = new Set();
function addConnectListener(listener) {
    connectListeners.add(listener);
    listener();
}
function addDisconnectListener(listener) {
    disconnectListeners.add(listener);
}
function addMessageListener(listener) {
    messageListeners.add(listener);
}
const connect = () => {
    if (port) {
        return port;
    }
    try {
        port = browser.runtime.connect({ name: "ui" });
    }
    catch (ex) {
        port = null;
        disconnectListeners.forEach((listener) => listener());
        return port;
    }
    port.onMessage.addListener((message) => {
        onMessage(message);
    });
    port.onDisconnect.addListener(onDisconnect);
    connectListeners.forEach((listener) => listener());
    return port;
};
function listen(_a) {
    var { type, filter } = _a, options = __rest(_a, ["type", "filter"]);
    addConnectListener(() => {
        if (port) {
            port.postMessage(Object.assign({ type: `${type}.listen`, filter }, options));
        }
    });
}
function onDisconnect() {
    port = null;
    setTimeout(() => connect(), 100);
}
function onMessage(message) {
    if (!message.type.endsWith(".respond")) {
        return;
    }
    messageListeners.forEach((listener) => listener(message));
}
function removeDisconnectListener(listener) {
    disconnectListeners.delete(listener);
}const platformToStore = {
    chromium: "chrome",
    edgehtml: "edge",
    gecko: "firefox"
};
const app = {
    get: (what) => send("app.get", { what }),
    getInfo: () => __awaiter(void 0, void 0, void 0, function* () {
        return Promise.all([app.get("application"), app.get("platform")]).then(([application, rawPlatform]) => {
            const platform = rawPlatform;
            let store;
            if (application !== "edge" && application !== "opera") {
                store = platformToStore[platform] || "chrome";
            }
            else {
                store = application;
            }
            return {
                application,
                platform,
                store
            };
        });
    }),
    listen: (filter) => listen({ type: "app", filter }),
    open: (what) => send("app.open", { what })
};
const ctalinks = {
    get: (link, queryParams = {}) => send("app.get", { what: "ctalink", link, queryParams })
};
const doclinks = {
    get: (link) => send("app.get", { what: "doclink", link })
};
const filters = {
    get: () => send("filters.get"),
    listen: (filter) => listen({ type: "filters", filter })
};
const notifications = {
    get: (displayMethod) => send("notifications.get", { displayMethod }),
    seen: () => send("notifications.seen")
};
const prefs = {
    get: (key) => send("prefs.get", { key }),
    listen: (filter) => listen({ type: "prefs", filter })
};
const premium = {
    activate: (userId) => send("premium.activate", { userId }),
    get: () => send("premium.get"),
    listen: (filter) => listen({ type: "premium", filter })
};
const requests = {
    listen: (filter, tabId) => listen({ type: "requests", filter, tabId })
};
function send(sendType, rawArgs = {}) {
    const args = Object.assign(Object.assign({}, rawArgs), { type: sendType });
    return browser.runtime.sendMessage(args);
}
const stats = {
    getBlockedPerPage: (tab) => send("stats.getBlockedPerPage", { tab }),
    getBlockedTotal: () => send("stats.getBlockedTotal"),
    listen: (filter) => listen({ type: "stats", filter })
};
const subscriptions = {
    get: (options) => send("subscriptions.get", options),
    getInitIssues: () => send("subscriptions.getInitIssues"),
    listen: (filter) => listen({ type: "subscriptions", filter })
};
const api = {
    addDisconnectListener,
    addListener: addMessageListener,
    app,
    ctalinks,
    doclinks,
    filters,
    notifications,
    prefs,
    premium,
    requests,
    removeDisconnectListener,
    subscriptions,
    stats
};
connect();function convertDoclinks()
{
  const links = document.querySelectorAll("a[data-doclink]");
  for (const link of links)
  {
    getDoclink(link.dataset.doclink).then((url) =>
    {
      link.target = link.target || "_blank";
      link.href = url;
    });
  }
}
function getDoclink(link)
{
  return browser.runtime.sendMessage({
    type: "app.get",
    what: "doclink",
    link
  });
}
function getErrorMessage(error)
{
  let message = null;
  if (error)
  {
    let messageId = error.reason || error.type;
    let placeholders = [];
    if (error.reason === "filter_unknown_option")
    {
      if (error.option)
        placeholders = [error.option];
      else
        messageId = "filter_invalid_option";
    }
    message = browser.i18n.getMessage(messageId, placeholders);
  }
  if (!message)
  {
    message = browser.i18n.getMessage("filter_action_failed");
  }
  if (!error || typeof error.lineno !== "number")
    return message;
  return browser.i18n.getMessage("line", [
    error.lineno.toLocaleString(),
    message
  ]);
}const i18nAttributes = ["alt", "placeholder", "title", "value"];
function setElementText(element, stringName, args, children = [])
{
  function processString(str, currentElement)
  {
    const match = /^(.*?)<(a|em|slot|strong)(\d)?>(.*?)<\/\2\3>(.*)$/.exec(str);
    if (match)
    {
      const [, before, name, index, innerText, after] = match;
      processString(before, currentElement);
      if (name == "slot")
      {
        const e = children[index];
        if (e)
        {
          currentElement.appendChild(e);
        }
      }
      else
      {
        const e = document.createElement(name);
        if (typeof index != "undefined")
        {
          e.dataset.i18nIndex = index;
        }
        processString(innerText, e);
        currentElement.appendChild(e);
      }
      processString(after, currentElement);
    }
    else
      currentElement.appendChild(document.createTextNode(str));
  }
  while (element.lastChild)
    element.removeChild(element.lastChild);
  processString(browser.i18n.getMessage(stringName, args), element);
}
function loadI18nStrings()
{
  function resolveStringNames(container)
  {
    {
      const elements = container.querySelectorAll("[data-i18n]");
      for (const element of elements)
      {
        const children = Array.from(element.children);
        setElementText(element, element.dataset.i18n, null, children);
      }
    }
    for (const attr of i18nAttributes)
    {
      const elements = container.querySelectorAll(`[data-i18n-${attr}]`);
      for (const element of elements)
      {
        const stringName = element.getAttribute(`data-i18n-${attr}`);
        element.setAttribute(attr, browser.i18n.getMessage(stringName));
      }
    }
  }
  resolveStringNames(document);
  for (const template of document.querySelectorAll("template"))
    resolveStringNames(template.content);
}
function initI18n()
{
  browser.runtime.sendMessage({
    type: "app.get",
    what: "localeInfo"
  })
  .then(localeInfo =>
  {
    document.documentElement.lang = localeInfo.locale;
    document.documentElement.dir = localeInfo.bidiDir;
  });
  loadI18nStrings();
}{
  const dialogSubscribe = "subscribe";
  const idAcceptableAds = "acceptableAds";
  const idRecommended = "subscriptions-recommended";
  const promisedAcceptableAdsUrl = getAcceptableAdsUrl();
  let allowlistFilter = null;
  function get(selector, origin)
  {
    return (origin || document).querySelector(selector);
  }
  function getAll(selector, origin)
  {
    return (origin || document).querySelectorAll(selector);
  }
  function create(parent, tagName, content, attributes, onclick)
  {
    const element = document.createElement(tagName);
    if (typeof content == "string")
    {
      element.textContent = content;
    }
    if (attributes)
    {
      for (const name in attributes)
      {
        element.setAttribute(name, attributes[name]);
      }
    }
    if (onclick)
    {
      element.addEventListener("click", (ev) =>
      {
        onclick(ev);
        ev.stopPropagation();
      });
    }
    parent.appendChild(element);
    return element;
  }
  function getInstalled()
  {
    return browser.runtime.sendMessage({type: "subscriptions.get"});
  }
  function getAcceptableAdsUrl()
  {
    return browser.runtime.sendMessage(
      {type: "app.get", what: "acceptableAdsUrl"});
  }
  function getRecommendedAds()
  {
    return browser.runtime.sendMessage({
      type: "app.get",
      what: "recommendations"
    })
    .then((recommendations) =>
    {
      return recommendations
        .filter((recommendation) => recommendation.type == "ads")
        .map((recommendation) =>
        {
          return {
            title: recommendation.title,
            url: recommendation.url
          };
        });
    });
  }
  function installSubscription(url, title)
  {
    browser.runtime.sendMessage({type: "subscriptions.add", url, title});
  }
  function uninstallSubscription(url)
  {
    browser.runtime.sendMessage({type: "subscriptions.remove", url});
  }
  function setFilter({disabled, text}, action)
  {
    if (!allowlistFilter || text != allowlistFilter)
      return;
    get("#enabled").checked = (action == "remove" || disabled);
  }
  function setSubscription(subscription, action)
  {
    const {disabled, filters, title, url} = subscription;
    if (disabled)
    {
      action = "remove";
    }
    if (/^~user/.test(url))
    {
      for (const filter of filters)
      {
        setFilter(filter, action);
      }
      return;
    }
    promisedAcceptableAdsUrl.then((acceptableAdsUrl) =>
    {
      if (url == acceptableAdsUrl)
      {
        get(`#${idAcceptableAds}`).checked = (action != "remove");
        return;
      }
      const listInstalled = get("#subscriptions-installed");
      const installed = get(`[data-url="${url}"]`, listInstalled);
      if (action == "remove")
      {
        if (installed)
        {
          installed.parentNode.removeChild(installed);
        }
        const recommended = get(`#${idRecommended} [data-url="${url}"]`);
        if (recommended)
        {
          recommended.classList.remove("installed");
        }
      }
      else if (installed)
      {
        const titleElement = get("span", installed);
        titleElement.textContent = title || url;
      }
      else if (action == "add")
      {
        const element = create(listInstalled, "li", null, {"data-url": url});
        create(element, "span", title || url);
        create(
          element, "button", null, {class: "remove"},
          () => uninstallSubscription(url)
        );
        const recommended = get(`#${idRecommended} [data-url="${url}"]`);
        if (recommended)
        {
          recommended.classList.add("installed");
        }
      }
    });
  }
  function setDialog(id, options)
  {
    if (!id)
    {
      delete document.body.dataset.dialog;
      return;
    }
    const fields = getAll(`#dialog-${id} input`);
    for (const field of fields)
    {
      const {name} = field;
      field.value = (options && name in options) ? options[name] : "";
    }
    setError(id, null);
    document.body.dataset.dialog = id;
  }
  function setError(dialogId, fieldName)
  {
    const dialog = get(`#dialog-${dialogId}`);
    if (fieldName)
    {
      dialog.dataset.error = fieldName;
    }
    else
    {
      delete dialog.dataset.error;
    }
  }
  function populateLists()
  {
    Promise.all([getInstalled(), getRecommendedAds()])
      .then(([installed, recommended]) =>
      {
        const listRecommended = get(`#${idRecommended}`);
        for (const {title, url} of recommended)
        {
          create(
            listRecommended, "li", title, {"data-url": url},
            (ev) =>
            {
              if (ev.target.classList.contains("installed"))
                return;
              setDialog(dialogSubscribe, {title, url});
            }
          );
        }
        for (const subscription of installed)
        {
          if (subscription.disabled)
            continue;
          setSubscription(subscription, "add");
        }
      })
      .catch((err) => console.error(err));
  }
  function onChange(ev)
  {
    if (ev.target.id != idAcceptableAds)
      return;
    promisedAcceptableAdsUrl.then((acceptableAdsUrl) =>
    {
      if (ev.target.checked)
      {
        installSubscription(acceptableAdsUrl, null);
      }
      else
      {
        uninstallSubscription(acceptableAdsUrl);
      }
    });
  }
  document.addEventListener("change", onChange);
  function toggleAllowlistFilter(toggle)
  {
    if (allowlistFilter)
    {
      browser.runtime.sendMessage(
        {
          type: (toggle.checked) ? "filters.remove" : "filters.add",
          text: allowlistFilter
        }
      ).then(errors =>
      {
        if (errors.length < 1)
          return;
        console.error(getErrorMessage(errors[0]));
        toggle.checked = !toggle.checked;
      });
    }
    else
    {
      console.error("Allowlist filter hasn't been initialized yet");
    }
  }
  function onClick(ev)
  {
    switch (ev.target.dataset.action)
    {
      case "close-dialog":
        setDialog(null);
        break;
      case "open-dialog":
        setDialog(ev.target.dataset.dialog);
        break;
      case "toggle-enabled":
        toggleAllowlistFilter(ev.target);
        ev.preventDefault();
        break;
    }
  }
  document.addEventListener("click", onClick);
  function onSubmit(ev)
  {
    const fields = ev.target.elements;
    const title = fields.title.value;
    const url = fields.url.value;
    if (!url)
    {
      setError(dialogSubscribe, "url");
    }
    else
    {
      installSubscription(url, title);
      setDialog(null);
    }
    ev.preventDefault();
  }
  document.addEventListener("submit", onSubmit);
  function onMessage(msg)
  {
    switch (msg.type)
    {
      case "app.respond": {
        switch (msg.action)
        {
          case "addSubscription":
            const [subscription] = msg.args;
            let {title, url} = subscription;
            if (!title || title == url)
            {
              title = "";
            }
            setDialog(dialogSubscribe, {title, url});
            break;
          case "showPageOptions":
            const [{host, allowlisted}] = msg.args;
            allowlistFilter = `@@||${host}^$document`;
            get("#enabled-domain").textContent = host;
            const toggle = get("#enabled");
            toggle.checked = !allowlisted;
            get("#enabled-container").hidden = false;
            break;
        }
        break;
      }
      case "filters.respond": {
        const action = (msg.action == "added") ? "add" : "remove";
        setFilter(msg.args[0], action);
        break;
      }
      case "subscriptions.respond": {
        const [subscription, property] = msg.args;
        switch (msg.action)
        {
          case "added":
            setSubscription(subscription, "add");
            break;
          case "changed":
            setSubscription(
              subscription,
              (property === "enabled") ? "add" : "update"
            );
            break;
          case "removed":
            setSubscription(subscription, "remove");
            break;
        }
        break;
      }
    }
  }
  api.addListener(onMessage);
  api.app.listen(["addSubscription", "showPageOptions"]);
  api.filters.listen(["added", "removed"]);
  api.subscriptions.listen(["added", "changed", "removed"]);
  convertDoclinks();
  initI18n();
  populateLists();
  getDoclink("privacy").then((url) =>
  {
    get("#privacy-policy").href = url;
  });
  getDoclink("imprint").then((url) =>
  {
    get("#imprint").href = url;
  });
}})();
